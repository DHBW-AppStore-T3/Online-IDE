/**
 * Aufgabe 2: Gerade oder Ungerade
 *
 * Schreibe eine Methode isEven(int n), die true zurückgibt,
 * wenn n gerade ist, und false, wenn n ungerade ist.
 *
 * Beispiele:
 *   isEven(4)  → true
 *   isEven(7)  → false
 *   isEven(0)  → true
 */
public class Aufgabe02_GeradeUngerade {

    public static boolean isEven(int n) {
        // TODO: Implementierung
        return false;
    }

    public static void main(String[] args) {
        System.out.println(isEven(4));  // true
        System.out.println(isEven(7));  // false
        System.out.println(isEven(0));  // true
    }
}
