/**
 * Aufgabe 6: Palindrom-Prüfung
 *
 * Schreibe eine Methode isPalindrome(String s), die true zurückgibt,
 * wenn der String vorwärts und rückwärts gleich ist (Groß-/Kleinschreibung
 * ignorieren).
 *
 * Beispiele:
 *   isPalindrome("Racecar")  → true
 *   isPalindrome("Anna")     → true
 *   isPalindrome("Hallo")    → false
 */
public class Aufgabe06_Palindrom {

    public static boolean isPalindrome(String s) {
        // TODO: Implementierung
        return false;
    }

    public static void main(String[] args) {
        System.out.println(isPalindrome("Racecar"));  // true
        System.out.println(isPalindrome("Anna"));     // true
        System.out.println(isPalindrome("Hallo"));    // false
    }
}
