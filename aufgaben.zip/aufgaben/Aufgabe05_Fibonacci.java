/**
 * Aufgabe 5: Fibonacci-Zahl
 *
 * Schreibe eine Methode fibonacci(int n), die die n-te Fibonacci-Zahl
 * zurückgibt. Die Folge beginnt mit: 0, 1, 1, 2, 3, 5, 8, 13, ...
 *
 * Beispiele:
 *   fibonacci(0)  → 0
 *   fibonacci(1)  → 1
 *   fibonacci(6)  → 8
 *   fibonacci(9)  → 34
 */
public class Aufgabe05_Fibonacci {

    public static int fibonacci(int n) {
        // TODO: Implementierung
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(fibonacci(0));  // 0
        System.out.println(fibonacci(1));  // 1
        System.out.println(fibonacci(6));  // 8
        System.out.println(fibonacci(9));  // 34
    }
}
