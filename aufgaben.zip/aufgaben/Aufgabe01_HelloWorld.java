/**
 * Aufgabe 1: Hello World
 *
 * Gib den Text "Hallo, Welt!" auf der Konsole aus.
 *
 * Erwartete Ausgabe:
 *   Hallo, Welt!
 */
public class Aufgabe01_HelloWorld {

    public static void main(String[] args) {
        // TODO: Implementiere die Ausgabe
    }
}
