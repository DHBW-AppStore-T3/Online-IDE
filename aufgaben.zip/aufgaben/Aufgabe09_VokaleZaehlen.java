/**
 * Aufgabe 9: Vokale zählen
 *
 * Schreibe eine Methode countVowels(String s), die die Anzahl der
 * Vokale (a, e, i, o, u — Groß- und Kleinschreibung) im String zählt.
 *
 * Beispiele:
 *   countVowels("Hallo Welt")  → 3
 *   countVowels("Java")        → 2
 *   countVowels("xyz")         → 0
 */
public class Aufgabe09_VokaleZaehlen {

    public static int countVowels(String s) {
        // TODO: Implementierung
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(countVowels("Hallo Welt"));  // 3
        System.out.println(countVowels("Java"));        // 2
        System.out.println(countVowels("xyz"));         // 0
    }
}