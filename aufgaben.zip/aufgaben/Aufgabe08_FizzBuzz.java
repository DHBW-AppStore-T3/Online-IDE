/**
 * Aufgabe 8: FizzBuzz
 *
 * Schreibe eine Methode fizzBuzz(int n), die folgende Regeln anwendet:
 *   - Ist n durch 3 teilbar → "Fizz"
 *   - Ist n durch 5 teilbar → "Buzz"
 *   - Ist n durch 3 und 5 teilbar → "FizzBuzz"
 *   - Sonst → die Zahl als String
 *
 * Beispiele:
 *   fizzBuzz(3)   → "Fizz"
 *   fizzBuzz(5)   → "Buzz"
 *   fizzBuzz(15)  → "FizzBuzz"
 *   fizzBuzz(7)   → "7"
 */
public class Aufgabe08_FizzBuzz {

    public static String fizzBuzz(int n) {
        // TODO: Implementierung
        return "";
    }

    public static void main(String[] args) {
        System.out.println(fizzBuzz(3));   // Fizz
        System.out.println(fizzBuzz(5));   // Buzz
        System.out.println(fizzBuzz(15));  // FizzBuzz
        System.out.println(fizzBuzz(7));   // 7
    }
}
