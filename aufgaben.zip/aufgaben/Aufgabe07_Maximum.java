/**
 * Aufgabe 7: Maximum in einem Array
 *
 * Schreibe eine Methode max(int[] zahlen), die den größten Wert
 * im Array zurückgibt. Gehe davon aus, dass das Array mindestens
 * ein Element enthält.
 *
 * Beispiele:
 *   max(new int[]{3, 1, 4, 1, 5, 9, 2})  → 9
 *   max(new int[]{-5, -1, -3})            → -1
 *   max(new int[]{42})                    → 42
 */
public class Aufgabe07_Maximum {

    public static int max(int[] zahlen) {
        // TODO: Implementierung
        return 0;
    }

    public static void main(String[] args) {
        System.out.println(max(new int[]{3, 1, 4, 1, 5, 9, 2}));  // 9
        System.out.println(max(new int[]{-5, -1, -3}));            // -1
        System.out.println(max(new int[]{42}));                    // 42
    }
}
