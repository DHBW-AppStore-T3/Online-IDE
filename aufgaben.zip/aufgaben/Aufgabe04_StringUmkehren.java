/**
 * Aufgabe 4: String umkehren
 *
 * Schreibe eine Methode reverse(String s), die den übergebenen
 * String rückwärts zurückgibt.
 *
 * Beispiele:
 *   reverse("Hallo")   → "ollaH"
 *   reverse("Java")    → "avaJ"
 *   reverse("")        → ""
 */
public class Aufgabe04_StringUmkehren {

    public static String reverse(String s) {
        // TODO: Implementierung
        return "";
    }

    public static void main(String[] args) {
        System.out.println(reverse("Hallo"));  // ollaH
        System.out.println(reverse("Java"));   // avaJ
        System.out.println(reverse(""));       // (leer)
    }
}
